#ifndef VERSTR
#define VERSTR "$Revision: 0.5.0 $ time " __TIME__ " " __DATE__
#endif
